#! bin/bash

#format post-train-save-lm.sh <graph> <model> <experiment export directory> <mode>
#usage post-train-save-lm.sh exp/tri3/graph exp/tri3 exp tri3
graph= $1 #$expdir/tri3_${sen}_${gauss}/graph #exp/tri3/graph 
model= $2 #$expdir/tri3_${sen}_${gauss}
expdir= $3 #/exp or dump/exp
mode= $4 #triphone/DNN/Monophone/CNN etc
suffix=$(date) 

echo "============================================================================"
echo "                          Saving Language Model                             "
echo "============================================================================"

#### Copy all necessary files to use new LM with this acoustic model
### and only necessary files to save space
   
#cp data_${corpus_name} ${corpus_name}_${run}
#### delete unneeded files
#rm -rf ${corpus_name}_${run}/train ${corpus_name}_${run}/test ${corpus_name}_${run}/lang_decode

language= urdu  #echo "Enter Language name:"
#read language

# copy acoustic model and decision tree to new dir
mkdir LM
mkdir LM/$language
mkdir LM/$language/model
mkdir LM/$language/model/$mode

cp $model/final.mdl LM/${language}/model/$mode/final.mdl
cp $model/tree $expdir/LM/${language}/model/$mode/tree
cp $graph $expdir/LM/${language}/model/$mode/graph

tar -zcvf LM-${language}.tar.gz LM/$language

# clean up
#rm -rf ${corpus_name}_${run}

# move for storage
mkdir compressed_experiments
    
mv LM-${language}.tar.gz compressed_experiments/LM-${language}-${suffix}.tar.gz
