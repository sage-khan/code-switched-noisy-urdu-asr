

# Copyright 2016    Vimal Manohar
# Apache 2.0.

""" This package contains modules and subpackages used in kaldi scripts.
"""

import common

__all__ = ["common"]
