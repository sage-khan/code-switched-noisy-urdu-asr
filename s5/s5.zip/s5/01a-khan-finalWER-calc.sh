#! bin/bash

#Format ./khan-finalWER-calc.sh <tri/DNN-graph-directory> <tri/dnn-model directory> <test data directory> <no.of jobs> <mode (mono/triphone/DNN)>
#Usage ./khan-finalWER-calc.sh exp/tri3/graph exp/tri3 data/test 5 triphone

#================================================
# Set Directories
#================================================
graph= $1 #$expdir/tri3_${sen}_${gauss}/graph #exp/tri3/graph 
model= $2 #$expdir/tri3_${sen}_${gauss}
test_dir= $3 #data/test
suffix=$(date) 
num_jobs= $4 #5
mode= $5 #triphone/DNN/Monophone/CNN etc

tag="ur_10h"

data_folder=data

train_data=train

test_data=test

train_dir=${data_folder}/$train_data

test_dir=${data_folder}/$test_data

dev_set="test"

test_sets="test"

expdir=exp_$tag
dumpdir=dump
mfccdir=mfcc

#================================================
# Initialize Variables
#================================================

numLeavesTri1=2000
numGaussTri1=10000

numLeavesMLLT=3500
numGaussMLLT=20000

numLeavesSAT=4200
numGaussSAT=40000

# speakers >= no.of jobs
feats_nj=4
train_nj=4
decode_nj=4

date=$(date)

decode_beam=5
decode_lattice_beam=3
decode_max_active_states=200

#================================================
# Set LM Directories
#================================================

train_lang=lang

train_lang_dir=${data_folder}/$train_lang

test_lang=lang_test

test_lang_dir=${data_folder}/$test_lang

lmdir=lmDir

echo "============================================================================"
echo "                          FINAL WER CALCULATION                              "
echo "============================================================================"

if [ "$#" -ne 5 ]; then
    echo "ERROR: $0"
    echo "USAGE: $0 <graph> <model> <test_dir> <suffix>"
    exit 1
fi

if [ 1 ]; then
    
    printf "\n####================####\n";
    printf "#### BEGIN DECODING ####\n";
    printf "####================####\n\n";
    
    # DECODE WITH TRIPHONES WITH SAT ADJUSTED FEATURES
    
    # steps/decode_fmllr.sh --cmd "$cmd" \
    #     --nj $num_processors \
    #     ${exp_dir}/triphones_lda_mllt_sat/graph \
    #     ${data_dir}/${test_dir} \
    #     "${exp_dir}"'/triphones_lda_mllt_sat/decode_'"${test_dir}" \
    #     $unknown_phone \
    #     $silence_phone \
    #     || exit 1;

    
    # DECODE WITH REGULAR TRIPHONES WITH VANILLA DELTA FEATURES

    printf "\n ### Decoding with $num_jobs jobs  ### "
    
    steps/decode.sh \
        --cmd "$train_cmd" \
        --nj $num_jobs \
        --beam $decode_beam \
        --lattice-beam $decode_lattice_beam \
        --max-active $decode_max_active_states \
        $graph \
        $model \
        $test_dir \
        $test_dir/decode \
        "SPOKEN_NOISE" \
        "SIL" \
        || printf "\n####\n#### ERROR: decode.sh \n####\n\n" \
        || exit 1;
    

    printf "#### BEGIN CALCULATE TRI WER ####\n";
    
    for x in $expdir/tri3_${sen}_${gauss}/decode_${datadir}; do				#cd $expdir/tri3_${sen}_${gauss}/decode_${datadir}   
        [ -d $x ] && grep "WER" $x/wer_* | utils/best_wer.sh > WER_${mode}_${suffix}.txt;
    done

    printf "\n####==============####\n";
    printf "#### END DECODING ####\n";
    printf "####==============####\n\n";

    echo "###"
    echo "graph = $graph" >> WER_${mode}_${suffix}.txt

    echo "###"
    echo "acoustic model = $model" >> WER_${mode}_${suffix}.txt
    ../../../src/gmmbin/gmm-info $model >> WER_${mode}_${suffix}.txt
    
    echo "###"
    echo "test dir = $test_dir" >> WER_${mode}${suffix}.txt
    
fi

