#!/bin/bash

. ./cmd.sh
[ -f path.sh ] && . ./path.sh
set -e

#================================================
#	SET SWITCHES
#================================================

#Switch these i.e. lm_prep upto tdnn_test to zero if you dont want this done else let them be 1

lm_prep=0

MFCC_extract=0

mono_train=0
mono_test=0

tri1_train=0
tri1_test=0

tri2_train=1
tri2_test=1

tri3_train=1
tri3_test=1

dnn_train=1
dnn_test=1

tdnn_train=1
tdnn_test=1

ctdnn_train=1
ctdnn_test=1

#================================================
# Set Directories
#================================================

tag="ur_10h"

data_folder=data

train_data=train

test_data=test

train_dir=${data_folder}/$train_data

test_dir=${data_folder}/$test_data

dev_set="test"

test_sets="test"

expdir=exp_$tag
dumpdir=dump
mfccdir=mfcc

#================================================
# Initialize Variables
#================================================

numLeavesTri1=2000
numGaussTri1=10000

numLeavesMLLT=3500
numGaussMLLT=20000

numLeavesSAT=4200
numGaussSAT=40000

# speakers >= no.of jobs
feats_nj=4
train_nj=4
decode_nj=4

date=$(date)

#================================================
# Set LM Directories
#================================================

train_lang=lang

train_lang_dir=${data_folder}/$train_lang

test_lang=lang_test

test_lang_dir=${data_folder}/$test_lang

lmdir=lmDir

#=========================================================================================================================================#

if [ $lm_prep == 1 ]; then

	echo ============================================================================
	echo "				Language Model Preparation			"
	echo ============================================================================
	
	### Use these to make desired files
	#utils/utt2spk_to_spk2utt.pl data/test/utt2spk >> spk2utt  #convert utt2spk to spk2utt using this
	#cut -d ' ' -f 2- text | sed 's/ /\n/g' | sort -u > words.txt #convert text file in test and train directory to words.txt using this
	#cut -d ' ' -f 2- lexicon.txt | sed 's/ /\n/g' | sort -u > nonsilence_phones.txt #make this in data/local/lang or data/local/dict where your lexicon.txt resides
	#echo 'SIL' $'\n''oov' > silence_phones.txt #make this in data/local/lang or data/local/dict where your lexicon.txt resides
	#echo 'SIL' > optional_silence.txt #make this in data/local/lang or data/local/dict where your lexicon.txt resides
	#cat lexicon.txt | tr '[:upper:]' '[:lower:]' >> lexicon-lower.txt (convertes upper case to lower)
	#cat lexicon.txt | tr '[:lower:]' '[:upper:]' >> lexicon-upper.txt (convertes lower case to upper)
	
#	utils/prepare_lang.sh $data_folder/local/dict \						# dictionary can be in data/local/lang                       
#		"!sil" $data_folder/local/$train_lang $data_folder/$train_lang || exit 1;		# Usage e.g. utils/prepare_lang.sh $data_folder/local/dict "!SIL" data/local/lang data/lang       

	utils/prepare_lang_subword.sh $data_folder/local/dict \						# dictionary can be in data/local/lang                       
		"!sil" $data_folder/local/$train_lang $data_folder/$train_lang || exit 1;		# Usage e.g. utils/prepare_lang.sh $data_folder/local/dict "!SIL" data/local/lang data/lang  
	
	utils/prepare_lm_subword.sh data/local/lm data/train/test data/local/lang/lexicon.txt	#use this to prepare LM
	
	bash utils/train_lms_srilm.sh $data_folder/$train_data $data_folder/$test_data \
		$data_folder $data_folder/local/$lmdir $train_lang || exit 1;
	mkdir -p $data_folder/$test_lang
	rm -r $data_folder/$test_lang/*
	cp -r $data_folder/$train_lang/* $data_folder/$test_lang/
	bash utils/arpa2G.sh $data_folder/local/$lmdir/lm.gz $data_folder/$train_lang $data_folder/$test_lang || exit 1;
	echo ============================================================================
	echo "                   Language Model created successfully     	        "
	echo ============================================================================
fi

if [ $MFCC_extract == 1 ]; then
	echo ============================================================================
	echo "         		MFCC Feature Extration & CMVN + Validation	        "
	echo ============================================================================

	for datadir in $train_data $test_data; do # $checking every wav file in test and train_data
		utils/fix_data_dir.sh ${data_folder}/${datadir}
		utils/validate_data_dir.sh ${data_folder}/${datadir}

		steps/make_mfcc.sh --cmd "$train_cmd" --nj 15 ${data_folder}/${datadir} $expdir/make_mfcc/${datadir} $mfccdir/${datadir} || exit 1;
		steps/compute_cmvn_stats.sh ${data_folder}/${datadir} $expdir/make_mfcc/${datadir} $mfccdir/${datadir} || exit 1;


	done
	
	echo "============================================================================"
	echo "                              FINISHED DATA PREP                            "
	echo "============================================================================"

fi



if [ $mono_train == 1 ]; then
	echo ============================================================================
	echo "                   MonoPhone Training                	        "
	echo ============================================================================
	steps/train_mono.sh --boost-silence 1.25 --beam 6 --totgauss 2000 --num-iters 50 --nj "$train_nj" --cmd "$train_cmd" $train_dir $train_lang_dir $expdir/mono || exit 1;
	#steps/train_mono.sh --boost-silence 1.25 --beam 6 --totgauss 2000 --num-iters 50 --nj 10 --cmd "run.pl" data/train data/lang exp/mono
	../../../src/gmmbin/gmm-info exp/mono/final.mdl	
fi

if [ $mono_test == 1 ]; then
	echo ============================================================================
	echo "                   MonoPhone Testing             	        "
	echo ============================================================================
	utils/mkgraph.sh --mono $test_lang_dir $expdir/mono $expdir/mono/graph || exit 1;   #usage utils/mkgraph.sh --mono data/lang exp/mono exp/mono/graphD
	
	for datadir in $test_sets; do #
		steps/decode.sh --nj "$decode_nj" --cmd "$decode_cmd" $expdir/mono/graph ${data_folder}/${datadir} $expdir/mono/decode_${datadir} || exit 1;
		# usage steps/decode.sh --nj 5 exp/mono/graphD data/test exp/mono/decode
	done

	echo "============================================================================"
	echo "                          Word Error Rate - Monophones                      "
	echo "============================================================================"

	cd $expdir/mono/decode_${datadir} #cd exp/mono/decode
	cat wer_*|grep "WER"| sort -n >> wer-mono-$date.txt
	cd ../../..
	
fi

if [ $tri1_train == 1 ]; then
	echo ============================================================================
	echo "           tri1 : Deltas + Delta-Deltas Training      "
	echo ============================================================================
	steps/align_si.sh --boost-silence 1.25 --beam 10 --retry-beam 40 --nj "$train_nj" --cmd "$train_cmd" $train_dir \
		$train_lang_dir $expdir/mono $expdir/mono_ali || exit 1;
	## Align delta-based triphones with boost silence
	#usage steps/align_si.sh --boost-silence 1.25 --nj "$train_nj" --cmd "$train_cmd" --beam 10 --retry-beam 40 data/train data/lang exp/mono exp/mono_ali	
	
	for sen in 5000; do
		for gauss in 20; do
			gauss=$(($sen * $gauss))
			# Train delta + delta-delta triphones 
			steps/train_deltas.sh --num-iters 40 --beam 10 --cmd "$train_cmd" $sen $gauss $train_dir $train_lang_dir $expdir/mono_ali \
			       	$expdir/tri1_${sen}_${gauss} || exit 1;
			#steps/train_deltas.sh --num-iters 40--beam 10 --cmd "$train_cmd" $numLeavesTri1 $numGaussTri1 data/train data/lang exp/mono_ali exp/tri1
		done
	done	
	../../../src/gmmbin/gmm-info exp/tri1_${sen}_${gauss}/final.mdl

fi

if [ $tri1_test == 1 ]; then
	echo ============================================================================
	echo "           tri1 : Deltas + Delta-Deltas  Decoding            "
	echo ============================================================================
	for sen in 5000; do
		for gauss in 20; do
			gauss=$(($sen * $gauss))
			utils/mkgraph.sh $test_lang_dir $expdir/tri1_${sen}_${gauss} $expdir/tri1_${sen}_${gauss}/graph || exit 1;  #utils/mkgraph.sh data/lang exp/tri1 exp/tri/graph
			for datadir in $test_sets; do #
				steps/decode.sh --nj "$decode_nj" --cmd "$decode_cmd" $expdir/tri1_${sen}_${gauss}/graph \
					${data_folder}/${datadir} $expdir/tri1_${sen}_${gauss}/decode_${datadir} || exit 1;  #steps/decode.sh --nj 5 exp/tri1/graph data/test exp/tri1/decode
			done
		done
	done
	echo "============================================================================"
	echo "                         TRIPHONE WORD ERROR RATE                           "
	echo "============================================================================"

	cd $expdir/tri1_${sen}_${gauss}/decode_${datadir} #cd exp/tri1/decode
	cat wer_*|grep "WER"| sort -n >> wer-tri1-$date.txt
	cd ../../..
fi


if [ $tri2_train == 1 ]; then
	echo ============================================================================
	echo "                 tri2 : LDA + MLLT Training                    "
	echo ============================================================================
	steps/align_si.sh --boost-silence 1.25 --beam 10 --retry-beam 40 --nj "$train_nj" --cmd "$train_cmd" $train_dir $train_lang_dir $expdir/tri1_${sen}_${gauss} \
		$expdir/tri1_ali || exit 1
	#steps/align_si.sh --boost-silence 1.25 --beam 10 --retry-beam 40 --nj "$train_nj" --cmd "$train_cmd" data/train data/lang exp/tri1 exp/tri1_ali
	
	
	for sen in 6000; do
		for gauss in 20; do
			gauss=$(($sen * $gauss))
			steps/train_lda_mllt.sh --splice-opts "--left-context=3 --right-context=3" --cmd "$train_cmd" --splice-opts "--left-context=3 --right-context=3" \
				$sen $gauss $train_dir $train_lang_dir $expdir/tri1_ali $expdir/tri2_${sen}_${gauss} || exit 1; 
			#steps/train_lda_mllt.sh --splice-opts "--left-context=3 --right-context=3" --cmd "$train_cmd" $numLeavesMLLT $numGaussMLLT data/train data/lang exp/tri1_ali exp/tri2
		done
	done
	../../../src/gmmbin/gmm-info $expdir/tri2_${sen}_${gauss}/final.mdl
fi

if [ $tri2_test == 1 ]; then
	echo ============================================================================
	echo "                 tri2 : LDA + MLLT Decoding                "
	echo ============================================================================
	for sen in 6000; do
		for gauss in 20; do
			gauss=$(($sen * $gauss))
			utils/mkgraph.sh $test_lang_dir $expdir/tri2_${sen}_${gauss} $expdir/tri2_${sen}_${gauss}/graph || exit 1;
			#utils/mkgraph.sh data/lang exp/tri1 exp/tri/graph
			
			for datadir in $test_sets; do #
				steps/decode.sh --nj "$decode_nj" --cmd "$decode_cmd" $expdir/tri2_${sen}_${gauss}/graph ${data_folder}/${datadir} \
					$expdir/tri2_${sen}_${gauss}/decode_${datadir} || exit 1;
				#steps/decode.sh --nj 5 exp/tri1/graph data/test exp/tri1/decode
			done
		done
	done
fi




if [ $tri3_train == 1 ]; then
	echo ============================================================================
	echo "              tri3 : LDA + MLLT + SAT Training               "
	echo ============================================================================
	# Align tri2 system with train data.
	steps/align_si.sh --boost-silence 1.25 --beam 10 --retry-beam 40 --nj "$train_nj" --cmd "$train_cmd" \
		--use-graphs true $train_dir $train_lang_dir $expdir/tri2_6000_120000 $expdir/tri2_ali || exit 1;
	
	#steps/align_si.sh --boost-silence 1.25 --beam 10 --retry-beam 40 --nj "$train_nj" --cmd "$train_cmd" --use-graphs true data/train data/lang exp/tri2 exp/tri2_ali
	
	for sen in 8000; do
		for gauss in 20; do
			gauss=$(($sen * $gauss))
			# From tri2 system, train tri3 which is LDA + MLLT + SAT.
			steps/train_sat.sh --cmd "$train_cmd" \
				$sen $gauss $train_dir $train_lang_dir $expdir/tri2_ali $expdir/tri3_${sen}_${gauss} || exit 1;
			#steps/train_sat.sh --cmd "$train_cmd" $numLeavesSAT $numGaussSAT data/train data/lang exp/tri2_ali exp/tri3
		done
	done
fi

if [ $tri3_test == 1 ]; then
	echo ============================================================================
	echo "              tri3 : LDA + MLLT + SAT Decoding    Start             "
	echo ============================================================================
	for sen in 8000; do
		for gauss in 20; do
			gauss=$(($sen * $gauss))
			utils/mkgraph.sh $test_lang_dir $expdir/tri3_${sen}_${gauss} $expdir/tri3_${sen}_${gauss}/graph || exit 1;
			#utils/mkgraph.sh data/lang_test exp/tri3 exp/tri3/graph
			for datadir in $test_sets; do #
				steps/decode_fmllr.sh --nj "$decode_nj" --cmd "$decode_cmd" $expdir/tri3_${sen}_${gauss}/graph \
				       	${data_folder}/${datadir} $expdir/tri3_${sen}_${gauss}/decode_${datadir} || exit 1;
				
				#steps/decode_fmllr.sh --nj "$decode_nj" --cmd "$decode_cmd" exp/tri3/graph data/test exp/tri3/decode
			done
		done
	done
	../../../src/gmmbin/gmm-info exp/tri3/final.mdl
	
	echo "============================================================================"
	echo "                         tri3 : LDA + MLLT + SAT WORD ERROR RATE            "
	echo "============================================================================"

	cd $expdir/tri3_${sen}_${gauss}/decode_${datadir} #cd exp/tri3/decode
	cat wer_*|grep "WER"| sort -n >> wer-tri_3-$date.txt
	cd ../../..

	echo "============================================================================"
	echo "                          Saving Language Model                             "
	echo "============================================================================"

	#### Copy all necessary files to use new LM with this acoustic model
	### and only necessary files to save space
    
	#cp data_${corpus_name} ${corpus_name}_${run}

	#### delete unneeded files
	#rm -rf ${corpus_name}_${run}/train ${corpus_name}_${run}/test ${corpus_name}_${run}/lang_decode

	language= urdu  #echo "Enter Language name:"
	#read language

	# copy acoustic model and decision tree to new dir
	mkdir LM/$language/model
	mkdir LM/$language/model/tri3
	#mkdir LM/$language/model/DNN
	cp $expdir/tri3_${sen}_${gauss}/final.mdl LM/${language}/model/tri3/final.mdl
	cp $expdir/tri3_${sen}_${gauss}/tree $expdir/LM/${language}/model/tri3/tree
	cp $expdir/tri3_${sen}_${gauss}/graph $expdir/LM/${language}/model/tri3/graph

	tar -zcvf LM-${language}.tar.gz LM/$language

	# clean up
	#rm -rf ${corpus_name}_${run}

	# move for storage
	mkdir compressed_experiments
    
	mv LM-${language}.tar.gz compressed_experiments/LM-${language}-${suffix}.tar.gz


fi

if [ $dnn_train == 1 ]; then
	echo "============================================================================"
	echo "                       Align Triphone LDA + MLLT + SAT                      "
	echo "============================================================================"

	#	Align
	#steps/align_si.sh --boost-silence 1.25 --beam 10 --retry-beam 40 --nj "$train_nj" --cmd "$train_cmd" --use-graphs true data/train data/lang exp/tri3 exp/tri3_ali

	steps/align_fmllr.sh --cmd "$train_cmd" --nj "$train_nj" data/train data/lang $expdir/tri3_${sen}_${gauss} exp/tri3_ali

	echo "============================================================================"
	echo "                          DNN Training                                      "
	echo "============================================================================"

	steps/nnet3/train_tdnn.sh --initial-learning-rate 0.0075 --final-learning-rate 0.001 --num-hidden-layers 4 --minibatch-size 64 --hidden-layer-dim 512 --num-jobs-nnet 12 \
	--num-epochs 15 ${data_folder}/${train_data} ${data_folder}/${train_lang} $expdir/tri3_ali $expdir/DNN
	
	for datadir in $test_sets; do #
		steps/decode_fmllr.sh --nj "$decode_nj" --cmd "$decode_cmd" $expdir/tri3_${sen}_${gauss}/graph \
				       	${data_folder}/${datadir} $expdir/nnet3_${sen}_${gauss}/decode_${datadir} || exit 1;
				
		#steps/nnet3/decode.sh --nj 4 $expdir/tri3_${sen}_${gauss}/graph ${data_folder}/${test_data} $expdir/nnet3_${sen}_${gauss}/decode
			done
	
	
	#steps/nnet3/train_tdnn.sh --initial-learning-rate 0.0075 --final-learning-rate 0.001 --num-hidden-layers 4 --minibatch-size 64 --hidden-layer-dim 512 --num-jobs-nnet 12 \
	#--num-epochs 15 data/train data/lang exp/tri3_ali exp/DNN
	#steps/nnet3/decode.sh --nj 4 exp/tri3/graph data/test exp/nnet3/decode


#	steps/nnet2/train_tanh.sh  - -initial-learning-rate 0.015  - -final-learning-rate 0.002  - -num-hidden-layers 1  - -minibatch-size 128  - -hidden-layer-dim 256  - -num-jobs-nnet 10  - -num-epochs 5  data/train  data/lang_bigram  exp/tri_ali  exp/DNN
	
#	steps/nnet2/decode.sh --nj 4 exp/tri/graph data/test exp/DNN/decode	
	echo "============================================================================"
	echo "                         DNN WORD ERROR RATE                                "
	echo "============================================================================"

	cd $expdir/nnet3_${sen}_${gauss}/decode_${datadir} 	#cd exp/DNN/decode
	cat wer_*|grep "WER"| sort -n >> wer-DNN-$date.txt
	cd ../../..

	echo "============================================================================"
	echo "                       Align NNET3                                          "
	echo "============================================================================"

	steps/nnet3/align.sh data/train data/lang exp/nnet3 exp/nnet3_ali

	echo "============================================================================"
	echo "                          Finished DNN                                      "
	echo "============================================================================"

	exit 0

fi

if [ $tdnn_train == 1 ]; then
	echo ============================================================================
	echo "                    	Chain2 TDNN Training                		 "
	echo ============================================================================
	# DNN hybrid system training parameters
	tdnn_stage=0
	tdnn_train_iter=-10 #default=-10
	. ./utils/parse_options.sh
	gmm=tri3_8000_160000
	nnet3_affix=_8000_160000
	affix=1i_7000
	tree_affix=7000
	local/chain2/Run_tdnn_1i.sh --stage $tdnn_stage --train_stage $tdnn_train_iter \
		--data_folder $data_folder --expdir $expdir \
		--train_set $train_data --gmm $gmm \
		--nnet3_affix $nnet3_affix \
		--affix $affix \
		--tree_affix $tree_affix \
		--mfccdir $mfccdir || exit 1;
fi

if [ $tdnn_test == 1 ]; then
	echo ============================================================================
	echo "                          Chain2 TDNN Testing                             "
	echo ============================================================================
	test_stage=1
	nnet3_affix=_8000_160000
	affix=1i_7000
	tree_affix=7000
	dir=$expdir/chain2${nnet3_affix}/tdnn${affix:+_$affix}_sp
	tree_dir=$expdir/chain2${nnet3_affix}/tree_a_sp${tree_affix:+_$tree_affix}
	graph_dir=$tree_dir/graph_gv

	if [ $test_stage -le 1 ]; then
		for datadir in $test_sets; do #
			utils/fix_data_dir.sh ${data_folder}/$datadir
			utils/copy_data_dir.sh ${data_folder}/$datadir ${data_folder}/${datadir}_hires
		done

		for datadir in $test_sets; do #
			steps/make_mfcc.sh --nj 5 --mfcc-config conf/mfcc_hires.conf --cmd "$train_cmd" \
				${data_folder}/${datadir}_hires $expdir/make_mfcc/${datadir}_hires $mfccdir/${datadir}_hires || exit 1;
			utils/fix_data_dir.sh ${data_folder}/${datadir}_hires
			steps/compute_cmvn_stats.sh ${data_folder}/${datadir}_hires $expdir/make_mfcc/${datadir}_hires \
				$mfccdir/${datadir}_hires || exit 1;
		done
	fi

	if [ $test_stage -le 2 ]; then
		for datadir in $test_sets; do #
			steps/online/nnet2/extract_ivectors_online.sh --cmd "$train_cmd" --nj 5 \
				${data_folder}/${datadir}_hires $expdir/nnet3${nnet3_affix}/extractor \
				$expdir/nnet3${nnet3_affix}/ivectors_${datadir}_hires || exit 1;
		done
	fi

	if [ $test_stage -le 3 ]; then
		# Note: it might appear that this $lang directory is mismatched, and it is as
		# far as the 'topo' is concerned, but this script doesn't read the 'topo' from
		# the lang directory.
		utils/mkgraph.sh --self-loop-scale 1.0 --remove-oov ${data_folder}/lang_test_gv $tree_dir $graph_dir
	fi

	iter_opts=
	decode_iter=
	if [ ! -z $decode_iter ]; then
		iter_opts=" --iter $decode_iter "
	fi
	if [ $test_stage -le 4 ]; then
		rm $dir/.error 2>/dev/null || true
		for decode_set in $test_sets; do
			(
				steps/nnet3/decode.sh --use-gpu true --acwt 1.0 --post-decode-acwt 10.0 --nj $decode_nj \                       #make gpu false if you done want to use
					--cmd "$decode_cmd" $iter_opts --online-ivector-dir \
					$expdir/nnet3${nnet3_affix}/ivectors_${decode_set}_hires $graph_dir \
					${data_folder}/${decode_set}_hires $dir/decode_${decode_set}${decode_iter:+_$decode_iter}_gv || exit 1;
			) || touch $dir/.error &
		done
		wait
		if [ -f $dir/.error ]; then
			echo "$0: something went wrong in decoding"
			exit 1
		fi
	fi # Decoding finished

	if [ $test_stage -le 5 ]; then
		rm $dir/.error 2>/dev/null || true
		for score_set in $test_sets; do
			(
				steps/scoring/score_kaldi_cer.sh --cmd "$decode_cmd" ${data_folder}/${score_set}_hires $graph_dir \
					$dir/decode_${decode_set}${decode_iter:+_$decode_iter}_gv || exit 1;
			) || touch $dir/.error &
		done
		wait
		if [ -f $dir/.error ]; then
			echo "$0: something went wrong in scoring"
			exit 1;
		fi
	fi # Scoring finished

	echo "============================================================================"
	echo "                          Saving Language Model                             "
	echo "============================================================================"

	#### Copy all necessary files to use new LM with this acoustic model
	### and only necessary files to save space
    
	#cp data_${corpus_name} ${corpus_name}_${run}

	#### delete unneeded files
	#rm -rf ${corpus_name}_${run}/train ${corpus_name}_${run}/test ${corpus_name}_${run}/lang_decode

	language= urdu  #echo "Enter Language name:"
	#read language

	# copy acoustic model and decision tree to new dir
	#mkdir LM/$language/model
	#mkdir LM/$language/model/tri3
	mkdir LM/$language/model/DNN
	cp $expdir/$expdir/nnet3${nnet3_affix}/final.mdl LM/${language}/model/DNN/final.mdl
	cp $expdir/nnet3${nnet3_affix}/tree $expdir/LM/${language}/model/DNN/tree
	cp $$expdir/nnet3${nnet3_affix}/graph $expdir/LM/${language}/model/DNN/graph

	tar -zcvf LM-${language}.tar.gz LM/$language

	# clean up
	#rm -rf ${corpus_name}_${run}

	# move for storage
	mkdir compressed_experiments
    
	mv LM-${language}.tar.gz compressed_experiments/LM-${language}-${suffix}.tar.gz

fi  # Testing finished

if [ $ctdnn_train == 1 ]; then
	echo ============================================================================
	echo "                    	Chain CNN-TDNN Training         		"
	echo ============================================================================
	tdnn_stage=0
        tdnn_train_iter=-10 #default=-10
        . ./utils/parse_options.sh
        gmm=tri3_8000_160000
        nnet3_affix=_8000_160000
        affix=cnn_1a_60001
        tree_affix=6000

        local/chain/Run_cnn_tdnn_1a.sh --stage $tdnn_stage --train_stage $tdnn_train_iter \
                --data_folder $data_folder --expdir $expdir \
                --train_set $train_data --gmm $gmm \
                --nnet3_affix $nnet3_affix \
                --affix $affix \
                --tree_affix $tree_affix \
                --mfccdir $mfccdir || exit 1;
fi

if [ $ctdnn_test == 1 ]; then
	echo ============================================================================
	echo "                          Chain CNN-TDNN Testing                          "
	echo ============================================================================
	test_stage=1
	nnet3_affix=_8000_160000
	affix=cnn_1a_60001
	dir=$expdir/chain${nnet3_affix}/tdnn${affix:+_$affix}_sp
	graph_dir=$dir/graph_gv

	if [ $test_stage -le 1 ]; then
		for datadir in $test_sets; do #
			utils/fix_data_dir.sh ${data_folder}/$datadir
			utils/copy_data_dir.sh ${data_folder}/$datadir ${data_folder}/${datadir}_hires
		done

		for datadir in $test_sets; do #
			steps/make_mfcc.sh --nj 5 --mfcc-config conf/mfcc_hires.conf --cmd "$train_cmd" \
				${data_folder}/${datadir}_hires $expdir/make_mfcc/${datadir}_hires $mfccdir/${datadir}_hires || exit 1;
			utils/fix_data_dir.sh ${data_folder}/${datadir}_hires
			steps/compute_cmvn_stats.sh ${data_folder}/${datadir}_hires $expdir/make_mfcc/${datadir}_hires \
				$mfccdir/${datadir}_hires || exit 1;
		done
	fi

	if [ $test_stage -le 2 ]; then
		for datadir in $test_sets; do #
			steps/online/nnet2/extract_ivectors_online.sh --cmd "$train_cmd" --nj 5 \
				${data_folder}/${datadir}_hires $expdir/nnet3${nnet3_affix}/extractor \
				$expdir/nnet3${nnet3_affix}/ivectors_${datadir}_hires || exit 1;
		done
	fi

	if [ $test_stage -le 3 ]; then
		# Note: it might appear that this $lang directory is mismatched, and it is as
		# far as the 'topo' is concerned, but this script doesn't read the 'topo' from
		# the lang directory.
		utils/mkgraph.sh --self-loop-scale 1.0 --remove-oov ${data_folder}/lang_test_gv $dir $graph_dir
	fi

	iter_opts=
	decode_iter=
	if [ ! -z $decode_iter ]; then
		iter_opts=" --iter $decode_iter "
	fi
	if [ $test_stage -le 4 ]; then
		rm $dir/.error 2>/dev/null || true
		for decode_set in $test_sets; do
			(
				steps/nnet3/decode.sh --use-gpu true --acwt 1.0 --post-decode-acwt 10.0 --nj $decode_nj \   #set gpu to false if you done wat to use this
					--cmd "$decode_cmd" $iter_opts --online-ivector-dir \
					$expdir/nnet3${nnet3_affix}/ivectors_${decode_set}_hires $graph_dir \
					${data_folder}/${decode_set}_hires $dir/decode_${decode_set}${decode_iter:+_$decode_iter}_gv || exit 1;
			) || touch $dir/.error &
		done
		wait
		if [ -f $dir/.error ]; then
			echo "$0: something went wrong in decoding"
			exit 1
		fi
	fi # Decoding finished

	if [ $test_stage -le 5 ]; then
		rm $dir/.error 2>/dev/null || true
		for score_set in $test_sets; do
			(
				steps/scoring/score_kaldi_cer.sh --cmd "$decode_cmd" ${data_folder}/${score_set}_hires $graph_dir \
					$dir/decode_${decode_set}${decode_iter:+_$decode_iter}_gv || exit 1;
			) || touch $dir/.error &
		done
		wait
		if [ -f $dir/.error ]; then
			echo "$0: something went wrong in scoring"
			exit 1;
		fi
	fi # Scoring finished

#	echo "============================================================================"
#	echo "                          Saving Language Model                             "
#	echo "============================================================================"

	#### Copy all necessary files to use new LM with this acoustic model
	### and only necessary files to save space
    
	#cp data_${corpus_name} ${corpus_name}_${run}

	#### delete unneeded files
	#rm -rf ${corpus_name}_${run}/train ${corpus_name}_${run}/test ${corpus_name}_${run}/lang_decode

#	language= urdu  #echo "Enter Language name:"
	#read language

	# copy acoustic model and decision tree to new dir
	#mkdir LM/$language/model
	#mkdir LM/$language/model/tri3
#	mkdir LM/$language/model/cnnet
#	cp $expdir/$expdir/nnet3${nnet3_affix}/final.mdl LM/${language}/model/cnnet/final.mdl
#	cp $expdir/nnet3${nnet3_affix}/tree $expdir/LM/${language}/model/cnnet/tree
#	cp $$expdir/nnet3${nnet3_affix}/graph $expdir/LM/${language}/model/cnnet/graph

#	tar -zcvf LM-${language}.tar.gz LM/$language

	# clean up
	#rm -rf ${corpus_name}_${run}

	# move for storage
#	mkdir compressed_experiments
    
#	mv LM-${language}.tar.gz compressed_experiments/LM-${language}-${suffix}.tar.gz
#fi  # Testing finished

echo ============================================================================
echo "                     Training Testing Finished                      "
echo ============================================================================





